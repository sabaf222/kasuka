# من کی‌ ام؟ 👨‍💻

<img align="center" src="https://raw.githubusercontent.com/imrrobat/imrrobat/d1b244e170d2b75fdda3efd499eaaf163f7a617c/images/github-contribution-grid-snake.svg" />

<h2 align="center">سلام 🖐 من محمد امین سعیدی راد هستم</h2>
<p align="center">
  برنامه نویس فرانت اند 🖥 مدرس برنامه نویسی ❤️ دانشجوی رشته مهندسی کامپیوتر 👨‍💻 و عاشق دنیای صفر و یک ✌️
</p>

<br />

<h2 align"right">ابزار هایی که استفاده می‌کنم 💪</h2>

![HTML5](https://img.shields.io/badge/html5-%23E34F26.svg?style=for-the-badge&logo=html5&logoColor=white) ![CSS3](https://img.shields.io/badge/css3-%231572B6.svg?style=for-the-badge&logo=css3&logoColor=white) ![JavaScript](https://img.shields.io/badge/javascript-%23323330.svg?style=for-the-badge&logo=javascript&logoColor=%23F7DF1E) ![React](https://img.shields.io/badge/react-%2320232a.svg?style=for-the-badge&logo=react&logoColor=%2361DAFB) ![Redux](https://img.shields.io/badge/redux-%23593d88.svg?style=for-the-badge&logo=redux&logoColor=white) ![TailwindCSS](https://img.shields.io/badge/tailwindcss-%2338B2AC.svg?style=for-the-badge&logo=tailwind-css&logoColor=white) ![TypeScript](https://img.shields.io/badge/typescript-%23007ACC.svg?style=for-the-badge&logo=typescript&logoColor=white) ![Next JS](https://img.shields.io/badge/Next-black?style=for-the-badge&logo=next.js&logoColor=white) ![NodeJS](https://img.shields.io/badge/node.js-6DA55F?style=for-the-badge&logo=node.js&logoColor=white)

<br />

<h2 align="right">تماس با من 📞</h2>
<a href="https://instagram.com/rad_front"><img width="50px" height="50px" align="left" src="https://github.com/sabzlearn-ir/sabzlearn-ir/blob/main/icons8-instagram-96.png?raw=true" alt="Instagram" /></a>
<a href="https://t.me/aminkhoy78"><img width="50px" height="50px"  align="left" src="https://github.com/sabzlearn-ir/sabzlearn-ir/blob/main/icons8-telegram-96.png?raw=true" alt="Telegram" /></a>

<br />

<h2 align="right">الان به چه کار هایی مشغول هستم 🌚</h2>

 <h3 align="right">🌟 توسعه بک‌اند آکادمی سبزلرن</h3>
 <h3 align="right">🌟 تدریس دوره گیت و گیت‌هاب</h3>
 <h3 align="right">🌟 تولید محتوا</h3>
 <h3 align="right">🌟 توسعه فرانت‌اند سایت Onlyjs</h3>

<br />

<h2 align="right">الان دارم با اینا کار می‌کنم 👨‍💻</h2>

<h3 align="left">🖥 JavaScript | 80%</h3> <img width="400px" src="https://github.com/sabzlearn-ir/sabzlearn-ir/blob/main/bar.png?raw=true" />

<br />

<h3 align="left">🖥 React Js | 50%</h3> <img width="250px" src="https://github.com/sabzlearn-ir/sabzlearn-ir/blob/main/bar.png?raw=true" />

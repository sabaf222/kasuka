import React, { Component } from 'react'

export default class Book extends Component {
    render() {
        return (
            <tr>
                <th>شاهنامه</th>
                <th>فردوسی</th>
                <th>1254</th>
            </tr>
        )
    }
}
